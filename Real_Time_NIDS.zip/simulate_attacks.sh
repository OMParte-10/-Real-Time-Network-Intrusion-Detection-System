#!/bin/bash
echo "Simulating ICMP flood attack..."
ping -f -c 100 127.0.0.1